// Stress test: tricky format cases the parser must survive.
// Compile with: g++ -std=c++17 -O2 -I src test/stress_test.cpp src/pdx_node.cpp -o build/stress_test

#include "pdx_node.h"
#include <cassert>
#include <iostream>
#include <string>

#define CHECK(cond) do { \
    if (!(cond)) { std::cerr << "FAIL " << #cond << " at line " << __LINE__ << "\n"; return 1; } \
    else { std::cout << "ok   " << #cond << "\n"; } \
} while (0)

int main() {
    // 1. Empty input
    {
        auto r = pdx::parse("");
        CHECK(r->kind == pdx::NodeKind::Block);
        CHECK(r->entries.empty());
    }

    // 2. Whitespace-only input
    {
        auto r = pdx::parse("   \n\t\r\n  ");
        CHECK(r->entries.empty());
    }

    // 3. Multiple values on one line in a list
    {
        auto r = pdx::parse("foo={ 1 2 3 4 5 }");
        auto* foo = r->find("foo");
        CHECK(foo);
        CHECK(foo->kind == pdx::NodeKind::Block);
        CHECK(foo->entries.size() == 5);
        CHECK(foo->entries[0].key.empty());
        CHECK(foo->entries[2].value->scalar == "3");
    }

    // 4. Duplicate keys preserved in order
    {
        auto r = pdx::parse("k=1 k=2 k=3");
        auto vals = r->find_all("k");
        CHECK(vals.size() == 3);
        CHECK(vals[0]->scalar == "1");
        CHECK(vals[2]->scalar == "3");
    }

    // 5. Mixed: technology="X" level=1 pattern from tech_status
    {
        auto r = pdx::parse("tech_status={ technology=\"a\" level=1 technology=\"b\" level=2 }");
        auto* ts = r->find("tech_status");
        CHECK(ts);
        auto techs = ts->find_all("technology");
        auto levels = ts->find_all("level");
        CHECK(techs.size() == 2);
        CHECK(levels.size() == 2);
        CHECK(techs[0]->scalar == "a");
        CHECK(levels[1]->scalar == "2");
    }

    // 6. Anonymous block list (player= pattern)
    {
        auto r = pdx::parse("player={ { name=\"X\" country=0 } { name=\"Y\" country=1 } }");
        auto* p = r->find("player");
        CHECK(p);
        // anonymous entries: keys empty
        int anon = 0;
        for (auto& e : p->entries) if (e.key.empty()) ++anon;
        CHECK(anon == 2);
    }

    // 7. Quoted vs unquoted distinction preserved
    {
        auto r = pdx::parse("a=\"0\" b=0");
        CHECK(r->find("a")->quoted == true);
        CHECK(r->find("b")->quoted == false);
        CHECK(r->find("a")->scalar == "0");
        CHECK(r->find("b")->scalar == "0");
    }

    // 8. Date sentinel
    {
        auto r = pdx::parse("d=\t\t\"0.01.01\"");
        CHECK(r->find("d")->scalar == "0.01.01");
        CHECK(r->find("d")->quoted == true);
    }

    // 9. Empty block
    {
        auto r = pdx::parse("a={ } b={}");
        CHECK(r->find("a")->kind == pdx::NodeKind::Block);
        CHECK(r->find("a")->entries.empty());
        CHECK(r->find("b")->kind == pdx::NodeKind::Block);
    }

    // 10. Deeply nested
    {
        auto r = pdx::parse("a={ b={ c={ d={ e=42 } } } }");
        auto* e = r->find("a")->find("b")->find("c")->find("d")->find("e");
        CHECK(e && e->scalar == "42");
    }

    // 11. Negative numbers and floats
    {
        auto r = pdx::parse("x=-1.5 y=-23.2477 z=15719.5887");
        CHECK(r->find("x")->as_double() == -1.5);
        CHECK(r->find("y")->as_double() == -23.2477);
    }

    // 12. Large integer (Stellaris uses values > 2^31)
    {
        auto r = pdx::parse("id=3758096385 huge=1825361929764");
        CHECK(r->find("id")->as_int() == 3758096385LL);
        CHECK(r->find("huge")->as_int() == 1825361929764LL);
    }

    // 13. Bare scalar list with nested object
    {
        auto r = pdx::parse("xs={ 1 2 { a=1 } 3 }");
        auto* xs = r->find("xs");
        CHECK(xs->entries.size() == 4);
        CHECK(xs->entries[2].value->kind == pdx::NodeKind::Block);
    }

    // 14. Tabs as whitespace inside scalars
    {
        auto r = pdx::parse("date=\t\t\t\"2200.01.01\"");
        CHECK(r->find("date")->scalar == "2200.01.01");
    }

    // 15. yes/no booleans
    {
        auto r = pdx::parse("a=yes b=no");
        CHECK(r->find("a")->as_yesno() == true);
        CHECK(r->find("b")->as_yesno() == false);
    }

    std::cout << "\nAll stress tests passed.\n";
    return 0;
}
