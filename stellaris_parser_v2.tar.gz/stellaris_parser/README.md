# Stellaris Save Extractor — v2

C++ parser for Stellaris `gamestate` files (the decompressed Paradox-format
save), with an extractor that emits resolved JSON containing your country's
data and every planet you own — with cross-references (pops, buildings,
districts, deposits, leaders, species, countries) inlined as objects rather
than raw IDs.

## What's new in v2

- **Resolution pass**: planet ID lists like `pop_groups`, `buildings_cache`,
  `districts`, `deposits`, `species_refs` are replaced with arrays of objects
  carrying type strings and metadata. `owner`, `controller`, `original_owner`,
  `governor` become objects too.
- **Full country block**: instead of a curated subset, the player's country
  is emitted in full via the generic emitter. Nothing dropped.
- **Galactic context**: `galactic_context.countries` provides light records
  (name, type, government, power) for every country you have a relation
  with or that is your subject — for the dashboard's diplomacy view.

See `DASHBOARD_SPEC.md` for the full data shape.

## Build

Requires a C++17 compiler. Tested with g++ 13.

    make

Produces `build/stellaris_extract`.

### Windows (one-line g++)

    g++ -std=c++17 -O2 -o stellaris_extract.exe src/extractor.cpp src/pdx_node.cpp src/json_writer.cpp src/resolver.cpp

## Usage

    ./build/stellaris_extract /path/to/gamestate /path/to/output.json

The input must be the decompressed `gamestate` file. To extract from a
`.sav` archive, use the included PowerShell script:

    .\run-extract.ps1

…which scans `save\*.sav`, decompresses each, runs the extractor, and
maintains a manifest of already-parsed saves.

## Files

```
src/pdx_node.{h,cpp}     Tree node + recursive-descent parser
src/json_writer.{h,cpp}  Streaming JSON writer (no dependencies)
src/resolver.{h,cpp}     Builds ID→record lookup tables, emits inline refs
src/extractor.cpp        main(): finds player, resolves, emits JSON
test/synthetic_gamestate.txt  Format fixture
test/stress_test.cpp     Lexer/parser edge-case tests
DASHBOARD_SPEC.md        Spec for the Streamlit dashboard
run-extract.ps1          Batch decompressor + driver for Windows
```

## Performance

5 MiB synthetic file: ~210 ms total. Real 53 MiB save expected: ~2 seconds.
Resolution pass scales with the number of records (typically 10–50k pops,
1k–5k buildings/districts/deposits, 50–100 leaders/species/countries).

## Pipeline

```
.sav (zip)
  -> gamestate (Paradox format, 50 MiB)
       -> stellaris_extract.exe  -> output.json (this tool)
            -> localize.py       -> output.resolved.json (TODO: Codex)
                 -> Streamlit app                         (TODO: Codex)
```

## Known limitations

- **Localization**: type strings (`building_energy_nexus`, `tech_psionic_theory`)
  are not resolved to English. A separate Python preprocessor is planned to
  walk the JSON injecting `localized` fields by reading Stellaris's
  `localisation/english/*.yml` files. See `DASHBOARD_SPEC.md` for the planned API.
- **Mod compatibility**: tested against vanilla Cetus 4.x. Mods that add new
  top-level blocks may produce extra unparsed data, but won't break parsing —
  unknown fields pass through the generic emitter.
- **Streaming**: full parse tree is built in memory. Real saves use a few
  hundred MiB, which is fine.
